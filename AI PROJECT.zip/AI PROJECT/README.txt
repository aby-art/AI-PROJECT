1. System must have python 3.6v (some of the libraries won't run in other versions)
2. install libraries (nltk, json, numpy, tflearn, tensorflow, pickle) 
3. open main.py ( make sure .json file is in the same folder)